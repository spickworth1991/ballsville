"use client";

// app/gauntlet/legions/page.jsx
// Static-export friendly: query params are read on the client.

import { useMemo } from "react";
import { useSearchParams } from "next/navigation";

import { CURRENT_SEASON } from "@/lib/season";

import GauntletLegionsClient from "@/components/gauntlet/GauntletLegionsClient";
import GauntletLegionClient from "@/components/gauntlet/GauntletLegionClient";

const LEGION_SLUGS = ["greeks", "romans", "egyptians"];

function normalizeLegion(raw) {
  const s = String(raw || "").trim().toLowerCase();
  if (!s) return null;
  // support a few common variants
  if (s === "greek" || s === "greece") return "greeks";
  if (s === "roman" || s === "rome") return "romans";
  if (s === "egypt" || s === "egyptian") return "egyptians";
  if (LEGION_SLUGS.includes(s)) return s;
  return null;
}

export default function GauntletLegionsPage() {
  const searchParams = useSearchParams();

  const legionSlug = useMemo(() => {
    return normalizeLegion(searchParams.get("legion"));
  }, [searchParams]);

  if (!legionSlug) {
    return <GauntletLegionsClient season={CURRENT_SEASON} />;
  }

  return (
    <GauntletLegionClient
      year={CURRENT_SEASON}
      legionSlug={legionSlug}
      backHref="/gauntlet/legions"
    />
  );
}
