export { default } from "../manifest/SectionManifestGate";
